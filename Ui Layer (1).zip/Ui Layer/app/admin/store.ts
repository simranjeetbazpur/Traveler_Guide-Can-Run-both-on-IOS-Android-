


class store
{
    store_json:any;
    constructor()
    {
this.store_json=undefined;
    }

}

export var json=new store();


