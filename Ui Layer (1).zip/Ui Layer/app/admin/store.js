"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var store = /** @class */ (function () {
    function store() {
        this.store_json = undefined;
    }
    return store;
}());
exports.json = new store();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RvcmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzdG9yZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUdBO0lBR0k7UUFFSixJQUFJLENBQUMsVUFBVSxHQUFDLFNBQVMsQ0FBQztJQUN0QixDQUFDO0lBRUwsWUFBQztBQUFELENBQUMsQUFSRCxJQVFDO0FBRVUsUUFBQSxJQUFJLEdBQUMsSUFBSSxLQUFLLEVBQUUsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuXHJcbmNsYXNzIHN0b3JlXHJcbntcclxuICAgIHN0b3JlX2pzb246YW55O1xyXG4gICAgY29uc3RydWN0b3IoKVxyXG4gICAge1xyXG50aGlzLnN0b3JlX2pzb249dW5kZWZpbmVkO1xyXG4gICAgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IHZhciBqc29uPW5ldyBzdG9yZSgpO1xyXG5cclxuXHJcbiJdfQ==